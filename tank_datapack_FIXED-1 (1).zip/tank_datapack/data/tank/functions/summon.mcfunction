summon minecraft:minecart ~ ~ ~ {CustomName:'"Tank"',Invulnerable:1b,Tags:["tank"]}
summon armor_stand ~ ~1 ~ {Invisible:1b,NoGravity:1b,Marker:1b,Tags:["tank_body"]}
execute as @a[nbt={RootVehicle:{Entity:{Tags:["tank"]}}}] run scoreboard players set @s drive 1
execute as @a[scores={drive=1}] run function tank:drive
execute as @a[scores={shoot=1..}] run function tank:shoot
scoreboard players set @a shoot 0
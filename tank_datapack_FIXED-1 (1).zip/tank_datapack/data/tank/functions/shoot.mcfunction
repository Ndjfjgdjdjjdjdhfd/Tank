execute as @a at @s run summon tnt ^ ^1 ^3 {Fuse:40}
data modify entity @e[type=tnt,limit=1,sort=nearest] Motion set value [0.0,0.2,1.5]
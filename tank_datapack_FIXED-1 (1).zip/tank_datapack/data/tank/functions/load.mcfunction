scoreboard objectives add drive dummy
scoreboard objectives add shoot minecraft.used:minecraft.carrot_on_a_stick